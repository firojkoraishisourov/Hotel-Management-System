package frames;

import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import entities.*;
import repositories.*;


public class AdminHomeFrame extends JFrame implements ActionListener
{
	
	private JButton adminBtn, employeeBtn, clientBtn, hotelBtn, roomBtn, paymentBtn,bookingBtn, bookingLineBtn, profileBtn, passBtn;
	private JPanel panel;
	private User u;
	
	public AdminHomeFrame(User u)
	{
		
		super("Admin Home Frame");
		this.setSize(800,400);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.panel=new JPanel();
		this.panel.setLayout(null);
		
		
		this.adminBtn=new JButton("Admin operation");
		this.adminBtn.setBounds(50,50,150,30);
		this.adminBtn.addActionListener(this);
		this.panel.add(adminBtn);
		
		this.employeeBtn=new JButton("Employee operation");
		this.employeeBtn.setBounds(210,50,150,30);
		this.employeeBtn.addActionListener(this);
		this.panel.add(employeeBtn);
		
		this.clientBtn=new JButton("Client operation");
		this.clientBtn.setBounds(370,50,150,30);
		this.clientBtn.addActionListener(this);
		this.panel.add(clientBtn);
		
		this.hotelBtn=new JButton("Hotel operation");
		this.hotelBtn.setBounds(530,50,150,30);
		this.hotelBtn.addActionListener(this);
		this.panel.add(hotelBtn);
		
		this.roomBtn=new JButton("Room operation");
		this.roomBtn.setBounds(50,100,150,30);
		this.roomBtn.addActionListener(this);
		this.panel.add(roomBtn);
		
		this.paymentBtn=new JButton("View all Paymentlist");
		this.paymentBtn.setBounds(210,100,150,30);
		this.paymentBtn.addActionListener(this);
		this.panel.add(paymentBtn);
		
		this.bookingBtn=new JButton("View all Bookinglist");
		this.bookingBtn.setBounds(370,100,200,30);
		this.bookingBtn.addActionListener(this);
		this.panel.add(bookingBtn);
		
		this.bookingLineBtn=new JButton("View all BookingLinelist");
		this.bookingLineBtn.setBounds(580,100,200,30);
		this.bookingLineBtn.addActionListener(this);
		this.panel.add(bookingLineBtn);
		
		this.profileBtn=new JButton("Update Profile");
		this.profileBtn.setBounds(50,150,200,30);
		this.profileBtn.addActionListener(this);
		this.panel.add(profileBtn);
		
		this.passBtn=new JButton("Update Password");
		this.passBtn.setBounds(50,150,200,30);
		this.passBtn.addActionListener(this);
		this.panel.add(passBtn);
		
		this.add(panel);
		this.u=u;
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		String command=ae.getActionCommand();
		
		if(command.equals(adminBtn.getText()))
		{
			AdminOperationFrame aof=new AdminOperationFrame(this.u);
			this.setVisible(false);
			aof.setVisible(true);
		}
		
		if(command.equals(paymentBtn.getText()))
		{
			AdminAllPayment aof=new AdminAllPayment(this.u);
			this.setVisible(false);
			aof.setVisible(true);
		}
		
		if(command.equals(profileBtn.getText()))
		{
			AdminUpdateProfileFrame aof=new AdminUpdateProfileFrame(this.u);
			this.setVisible(false);
			aof.setVisible(true);
		}
		
		if(command.equals(passBtn.getText()))
		{
			AdminUpdatePasswordFrame aof=new AdminUpdatePasswordFrame(this.u);
			this.setVisible(false);
			aof.setVisible(true);
		}
		
		if(command.equals(employeeBtn.getText()))
		{
			AdminAllPayment aof=new AdminAllPayment(this.u);
			this.setVisible(false);
			aof.setVisible(true);
		}
		
		if(command.equals(clientBtn.getText()))
		{
			ClientOperationFrame cof=new ClientOperationFrame(this.u);
			this.setVisible(false);
			cof.setVisible(true);
		}
		
		
		
	}
	
}
