package frames;

import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import entities.*;
import repositories.*;


public class EmployeeHomeFrame extends JFrame implements ActionListener
{
	
	private JButton clientBtn, hotelBtn, roomBtn, takePaymentBtn, paymentListBtn,bookingBtn, bookingLineBtn, profileBtn, passBtn;
	private JPanel panel;
	private User u;
	public EmployeeHomeFrame(User u)
	{
		super("Employee Home Frame");
		this.setSize(800,400);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.panel=new JPanel();
		this.panel.setLayout(null);
		
		
		this.clientBtn=new JButton("Client operation");
		this.clientBtn.setBounds(50,50,150,30);
		this.clientBtn.addActionListener(this);
		this.panel.add(clientBtn);
		
		this.hotelBtn=new JButton("Hotel operation");
		this.hotelBtn.setBounds(210,50,150,30);
		this.hotelBtn.addActionListener(this);
		this.panel.add(hotelBtn);
		
		this.roomBtn=new JButton("Room operation");
		this.roomBtn.setBounds(370,50,150,30);
		this.roomBtn.addActionListener(this);
		this.panel.add(roomBtn);
		
		this.takePaymentBtn=new JButton("Take Payment");
		this.takePaymentBtn.setBounds(530,50,150,30);
		this.takePaymentBtn.addActionListener(this);
		this.panel.add(takePaymentBtn);
		
		this.paymentListBtn=new JButton("View all paymentlist");
		this.paymentListBtn.setBounds(50,100,150,30);
		this.paymentListBtn.addActionListener(this);
		this.panel.add(paymentListBtn);
		
		this.bookingBtn=new JButton("View all Bookinglist");
		this.bookingBtn.setBounds(210,100,150,30);
		this.bookingBtn.addActionListener(this);
		this.panel.add(bookingBtn);
		
		this.bookingLineBtn=new JButton("View all BookingLinelist");
		this.bookingLineBtn.setBounds(370,100,200,30);
		this.bookingLineBtn.addActionListener(this);
		this.panel.add(bookingLineBtn);
		
		this.profileBtn=new JButton("Update Profile");
		this.profileBtn.setBounds(580,100,200,30);
		this.profileBtn.addActionListener(this);
		this.panel.add(profileBtn);
		
		this.passBtn=new JButton("Update Password");
		this.passBtn.setBounds(50,150,200,30);
		this.passBtn.addActionListener(this);
		this.panel.add(passBtn);
		
		
		
		
		
		this.add(panel);
		
		this.u=u;
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		String command=ae.getActionCommand();
		
		if(command.equals(bookingBtn.getText()))
		{
			EmployeeHomeFrame erbf=new EmployeeHomeFrame(this.u);
			this.setVisible(false);
			erbf.setVisible(true);
		}
	}
	
}