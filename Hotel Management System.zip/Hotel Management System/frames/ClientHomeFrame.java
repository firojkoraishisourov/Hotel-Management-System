package frames;

import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import entities.*;
import repositories.*;


public class ClientHomeFrame extends JFrame implements ActionListener
{
	
	private JButton hotelBtn, roomBtn, bookRoomBtn, doPaymentBtn, selfPaymentBtn, selfbookingBtn, selfbookingLineBtn, profileBtn, passBtn;
	private JPanel panel;
	private User u;
	public ClientHomeFrame(User u)
	{
		super("Student Home Frame");
		this.setSize(800,400);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.panel=new JPanel();
		this.panel.setLayout(null);
		
		
		this.hotelBtn=new JButton("View Hotellist");
		this.hotelBtn.setBounds(50,50,150,30);
		this.hotelBtn.addActionListener(this);
		this.panel.add(hotelBtn);
		
		this.roomBtn=new JButton("View Roomlist");
		this.roomBtn.setBounds(210,50,150,30);
		this.roomBtn.addActionListener(this);
		this.panel.add(roomBtn);
		
		this.bookRoomBtn=new JButton("Room Operation");
		this.bookRoomBtn.setBounds(370,50,150,30);
		this.bookRoomBtn.addActionListener(this);
		this.panel.add(bookRoomBtn);
		
		this.doPaymentBtn=new JButton("Payment operation");
		this.doPaymentBtn.setBounds(530,50,150,30);
		this.doPaymentBtn.addActionListener(this);
		this.panel.add(doPaymentBtn);
		
		this.selfPaymentBtn=new JButton("View PaymanetList");
		this.selfPaymentBtn.setBounds(50,100,150,30);
		this.selfPaymentBtn.addActionListener(this);
		this.panel.add(selfPaymentBtn);
		
		this.selfbookingBtn=new JButton("View Bookinglist");
		this.selfbookingBtn.setBounds(210,100,150,30);
		this.selfbookingBtn.addActionListener(this);
		this.panel.add(selfbookingBtn);
		
		this.selfbookingLineBtn=new JButton("View BookingLinelist");
		this.selfbookingLineBtn.setBounds(370,100,200,30);
		this.selfbookingLineBtn.addActionListener(this);
		this.panel.add(selfbookingLineBtn);
		
		this.profileBtn=new JButton("Update Profile");
		this.profileBtn.setBounds(580,100,200,30);
		this.profileBtn.addActionListener(this);
		this.panel.add(profileBtn);
		
		this.passBtn=new JButton("Update password");
		this.passBtn.setBounds(50,150,200,30);
		this.passBtn.addActionListener(this);
		this.panel.add(passBtn);
		
		
		
		
		
		
		this.add(panel);
		
		this.u=u;
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		String command=ae.getActionCommand();
		
		if(command.equals(selfPaymentBtn.getText()))
		{
			ClientSelfPaymentListFrame cpl=new ClientSelfPaymentListFrame(this.u);
			this.setVisible(false);
			cpl.setVisible(true);
		}
	}
	
}
