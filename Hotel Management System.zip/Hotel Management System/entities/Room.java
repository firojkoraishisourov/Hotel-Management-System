package entities;
import java.lang.*;

public class Room
{
	private String roomId,hotelId,type,serviceDetails;
	private int rentPerNight;
	
	public Room()
	{
	}
	
	public Room(String roomId,String hotelId,String type,int rentPerNight, String serviceDetails)
	{
		this.roomId=roomId;
		this.hotelId=hotelId;
		this.type=type;
		this.rentPerNight=rentPerNight;
		this.serviceDetails=serviceDetails;
	}
	
	public void setRoomId(String roomId)
	{
		this.roomId=roomId;
	}
	
	public void setHotelId(String hotelId)
	{
		this.hotelId=hotelId;
	}
	
	public void setType(String type)
	{
		this.type=type;
	}
	
	public void setRentPerNight(int rentPerNight)
	{
		this.rentPerNight=rentPerNight;
	}
	
	public void setServiceDetails(String serviceDetails)
	{
		this.serviceDetails=serviceDetails;
	}
	
	public String getRoomId()
	{
		return this.roomId;
	}
	
	public String getHotelId()
	{
		return this.hotelId;
	}
	
	public String getType()
	{
		return this.type;
	}
	
	public int getRentPerNight()
	{
		return this.rentPerNight;
	}
	
	public String getServiceDetails()
	{
		return this.serviceDetails;
	}
	
	public String toStringRoom()
	{
		String str=this.roomId+","+this.hotelId+","+this.type+","+this.rentPerNight+","+this.serviceDetails+"\n";
		return str;
	}
	
	public Room formRoom(String str)
	{
		String[] info=str.split(",");
		Room r=new Room();
		r.setRoomId(info[0]);
		r.setHotelId(info[1]);
		r.setType(info[2]);
		r.setRentPerNight(Integer.parseInt(info[3]));
		r.setServiceDetails(info[4]);
		return r;
	}
}