package interfaces;
import java.lang.*;
import entities.*;


public interface IRoomRepo
{
	void addRoom(Room r);
	void removeRoom(String key);
	void updateRoom(Room r);
	Room searchRoomByUserId(String id);
	Room[] getAllRoom();
	
}