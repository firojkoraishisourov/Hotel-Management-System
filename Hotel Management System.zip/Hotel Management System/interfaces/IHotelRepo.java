package interfaces;
import java.lang.*;
import entities.*;


public interface IHotelRepo
{
	void addHotel(Hotel h);
	void removeHotel(String key);
	void updateHotel(Hotel h);
	Hotel searchHotelByHotelId(String id);
	Hotel[] getAllHotel();
	
}