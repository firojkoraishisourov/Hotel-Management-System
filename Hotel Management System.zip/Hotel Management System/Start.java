import java.lang.*;
import frames.*;


public class Start
{
	public static void main(String[] args)
	{
		LoginFrame lf=new LoginFrame();
		lf.setVisible(true);
	}
}