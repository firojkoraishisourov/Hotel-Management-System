package repositories;
import java.lang.*;
import java.util.*;
import entities.*;
import interfaces.*;
public class HotelRepo implements IHotelRepo
{
	public void addHotel(Hotel h)
	{
		Hotel[] hotelList=this.getAllHotel();
		
		for(int i=0;i<hotelList.length;i++)
		{
			if(hotelList[i]==null)
			{
				hotelList[i]=h;
				break;
			}
		}
		
		this.write(hotelList);
	}
	public void removeHotel(String key)
	{
		Hotel[] hotelList=this.getAllHotel();
		
		for(int i=0;i<hotelList.length;i++)
		{
			if(hotelList[i]!=null)
			{
				if(hotelList[i].getHotelId().equals(key))
				{
					hotelList[i]=null;
					break;
				}
			}
			
		}
		
		this.write(hotelList);
	}
	public void updateHotel(Hotel h)
	{
		Hotel[] hotelList=this.getAllHotel();
		
		for(int i=0;i<hotelList.length;i++)
		{
			if(hotelList[i]!=null)
			{
				if(hotelList[i].getHotelId().equals(h.getHotelId()))
				{
					hotelList[i]=h;
					break;
				}
			}
			
		}
		
		this.write(hotelList);
	}
	public Hotel searchHotelByHotelId(String id)
	{
		Hotel[] hotelList=this.getAllHotel();
		
		for(int i=0;i<hotelList.length;i++)
		{
			if(hotelList[i]!=null)
			{
				if(hotelList[i].getHotelId().equals(id))
				{
					return hotelList[i];
				}
			}
			
		}

		return null;
	}
	public Hotel[] getAllHotel()
	{
		FileIO fio=new FileIO();
		String[] data= fio.readFile("repositories/data/hotel.txt");
		
		
		Hotel h=new Hotel();
		Hotel[] hotelList=new Hotel[100];
		int i=0;
		for(String str:data)
		{
			
			if(str!=null)
			{
				System.out.println(str);
				hotelList[i]=h.formHotel(str);
				
			}
			
			i++;
		}
		
		return hotelList;
	}
	
	public void write(Hotel[] hotelList)
	{
		String[] data=new String[100];
		for(int i=0;i<100;i++)
		{
			if(hotelList[i]!=null)
			{
				data[i]=hotelList [i].toStringHotel();
			}
			
		}
		FileIO fio=new FileIO();
		fio.writeFile(data, "repositories/data/hotel.txt");
	}
}