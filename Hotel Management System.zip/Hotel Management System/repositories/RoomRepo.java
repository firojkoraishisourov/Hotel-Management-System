package repositories;
import java.lang.*;
import java.util.*;
import entities.*;
import interfaces.*;
public class RoomRepo implements IRoomRepo
{
	public void addRoom(Room r)
	{
		Room[] roomList=this.getAllRoom();
		
		for(int i=0;i<roomList.length;i++)
		{
			if(roomList[i]==null)
			{
				roomList[i]=r;
				break;
			}
		}
		
		this.write(roomList);
	}
	public void removeRoom(String key)
	{
		Room[] roomList=this.getAllRoom();
		
		for(int i=0;i<roomList.length;i++)
		{
			if(roomList[i]!=null)
			{
				if(roomList[i].getRoomId().equals(key))
				{
					roomList[i]=null;
					break;
				}
			}
			
		}
		
		this.write(roomList);
	}
	public void updateRoom(Room r)
	{
		Room[] roomList=this.getAllRoom();
		
		for(int i=0;i<roomList.length;i++)
		{
			if(roomList[i]!=null)
			{
				if(roomList[i].getRoomId().equals(r.getRoomId()))
				{
					roomList[i]=r;
					break;
				}
			}
			
		}
		
		this.write(roomList);
	}
	public Room searchRoomByRoomId(String id)
	{
		Room[] roomList=this.getAllRoom();
		
		for(int i=0;i<roomList.length;i++)
		{
			if(roomList[i]!=null)
			{
				if(roomList[i].getRoomId().equals(id))
				{
					return roomList[i];
				}
			}
			
		}

		return null;
	}
	
	public Room[] searchRoomByHotelId(String id)
	{
		Room[] roomList=this.getAllRoom();
		Room[] foundRoom=new Room[100];
		
		for(int i=0;i<roomList.length;i++)
		{
			if(roomList[i]!=null)
			{
				if(roomList[i].getHotelId().equals(id))
				{
					foundRoom[i]=roomList[i];
				}
			}
			
		}

		return foundRoom;
	}
	
	public Room[] getAllRoom()
	{
		FileIO fio=new FileIO();
		String[] data= fio.readFile("repositories/data/room.txt");
		
		
		Room r=new Room();
		Room[] roomList=new Room[100];
		int i=0;
		for(String str:data)
		{
			
			if(str!=null)
			{
				System.out.println(str);
				roomList[i]=r.formRoom(str);
				
			}
			
			i++;
		}
		
		return roomList;
	}
	
	public void write(Room[] roomList)
	{
		String[] data=new String[100];
		for(int i=0;i<100;i++)
		{
			if(roomList[i]!=null)
			{
				data[i]=roomList [i].toStringRoom();
			}
			
		}
		FileIO fio=new FileIO();
		fio.writeFile(data, "repositories/data/room.txt");
	}
}